package com.example.confetteria_splendore.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.example.confetteria_splendore.model.User
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.tasks.await

class AuthRepository {

    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    /**
     * Faz o login do usuário com email e senha.
     * @param email O email do usuário.
     * @param password A senha do usuário.
     * @return Task<AuthResult> que indica o sucesso ou falha da operação.
     */
    suspend fun login(email: String, password: String): FirebaseUser? {
        return try {
            val authResult: AuthResult = firebaseAuth.signInWithEmailAndPassword(email, password).await()
            authResult.user
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Faz o cadastro do usuário com email e senha.
     * @param email O email do usuário.
     * @param password A senha do usuário.
     * @param user O objeto User com dados adicionais.
     * @return Task<AuthResult> que indica o sucesso ou falha da operação.
     */
    suspend fun register(email: String, password: String, user: User): FirebaseUser? {
        return try {
            val authResult: AuthResult = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            val firebaseUser = authResult.user
            firebaseUser?.let {
                // Salva os dados do usuário no Firestore após a criação
                saveUserToFirestore(firebaseUser.uid, user)
            }
            firebaseUser
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Salva os dados do usuário no Firestore.
     * @param userId O ID do usuário no Firebase Authentication.
     * @param user O objeto User com os dados do usuário.
     */
    private suspend fun saveUserToFirestore(userId: String, user: User) {
        try {
            firestore.collection("users")
                .document(userId)
                .set(user.toMap())
                .await()
        } catch (e: Exception) {
            // Lidar com o erro de gravação no Firestore
        }
    }

    /**
     * Realiza o logout do usuário.
     */
    fun logout() {
        firebaseAuth.signOut()
    }

    /**
     * Verifica se o usuário está autenticado.
     * @return Boolean indicando se o usuário está autenticado.
     */
    fun isUserAuthenticated(): Boolean {
        return firebaseAuth.currentUser != null
    }

    /**
     * Obtém o usuário autenticado.
     * @return FirebaseUser ou null caso não esteja autenticado.
     */
    fun getCurrentUser(): FirebaseUser? {
        return firebaseAuth.currentUser
    }
}

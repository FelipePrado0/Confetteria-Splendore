package com.example.confetteria_splendore.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.example.confetteria_splendore.model.MenuItem
import kotlinx.coroutines.tasks.await

class MenuViewModel : ViewModel() {

    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    // Lista de itens do menu como LiveData para ser observada pela UI
    private val _menuItems = MutableLiveData<List<MenuItem>>()
    val menuItems: LiveData<List<MenuItem>> get() = _menuItems

    // Estado de erro caso algo dê errado
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> get() = _errorMessage

    /**
     * Carrega todos os itens do cardápio do Firestore.
     */
    suspend fun loadMenuItems() {
        try {
            val snapshot = firestore.collection("menu").get().await()
            val items = snapshot.documents.mapNotNull { it.toObject(MenuItem::class.java) }
            _menuItems.postValue(items)
            _errorMessage.postValue(null) // Limpa qualquer mensagem de erro
        } catch (e: Exception) {
            _errorMessage.postValue("Erro ao carregar itens do menu: ${e.message}")
            _menuItems.postValue(emptyList()) // Atualiza para lista vazia em caso de erro
        }
    }

    /**
     * Recupera itens do cardápio filtrados por categoria.
     * @param category Categoria desejada.
     */
    suspend fun loadMenuItemsByCategory(category: String) {
        try {
            val snapshot = firestore.collection("menu")
                .whereEqualTo("category", category)
                .get()
                .await()
            val items = snapshot.documents.mapNotNull { it.toObject(MenuItem::class.java) }
            _menuItems.postValue(items)
            _errorMessage.postValue(null) // Limpa qualquer mensagem de erro
        } catch (e: Exception) {
            _errorMessage.postValue("Erro ao filtrar itens por categoria: ${e.message}")
            _menuItems.postValue(emptyList()) // Atualiza para lista vazia em caso de erro
        }
    }

    /**
     * Adiciona um novo item ao cardápio.
     * @param menuItem Item do cardápio a ser adicionado.
     * @return Sucesso ou falha como Boolean.
     */
    suspend fun addMenuItem(menuItem: MenuItem): Boolean {
        return try {
            firestore.collection("menu").add(menuItem).await()
            true
        } catch (e: Exception) {
            _errorMessage.postValue("Erro ao adicionar item: ${e.message}")
            false
        }
    }

    /**
     * Atualiza um item do cardápio existente.
     * @param itemId ID do item.
     * @param menuItem Dados atualizados do item.
     * @return Sucesso ou falha como Boolean.
     */
    suspend fun updateMenuItem(itemId: String, menuItem: MenuItem): Boolean {
        return try {
            firestore.collection("menu").document(itemId).set(menuItem).await()
            true
        } catch (e: Exception) {
            _errorMessage.postValue("Erro ao atualizar item: ${e.message}")
            false
        }
    }

    /**
     * Exclui um item do cardápio.
     * @param itemId ID do item.
     * @return Sucesso ou falha como Boolean.
     */
    suspend fun deleteMenuItem(itemId: String): Boolean {
        return try {
            firestore.collection("menu").document(itemId).delete().await()
            true
        } catch (e: Exception) {
            _errorMessage.postValue("Erro ao excluir item: ${e.message}")
            false
        }
    }
}

package com.example.confetteria_splendore.model

import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Representa um pedido realizado pelo cliente.
 */
data class OrderItem(
    val id: String = "",
    val userId: String = "", // Garantir que o userId seja passado
    val itens: MutableList<MenuItem> = mutableListOf(),
    val quantidades: MutableMap<String, Int> = mutableMapOf(),
    var total: Double = 0.0,  // A variável total agora é mutável para ser atualizada
    val timestamp: Long = System.currentTimeMillis()
) {

    /**
     * Adiciona um item ao pedido.
     * Se o item já existe, incrementa sua quantidade.
     */
    fun addItem(item: MenuItem) {
        if (quantidades.containsKey(item.id)) {
            quantidades[item.id] = quantidades[item.id]!! + 1
        } else {
            itens.add(item)
            quantidades[item.id] = 1
        }
        calculateTotal()
    }

    /**
     * Remove um item do pedido.
     * Se a quantidade do item for maior que 1, decrementa.
     * Se for 1, remove o item do pedido.
     */
    fun removeItem(item: MenuItem) {
        if (quantidades.containsKey(item.id)) {
            val currentQuantity = quantidades[item.id]!!
            if (currentQuantity > 1) {
                quantidades[item.id] = currentQuantity - 1
            } else {
                quantidades.remove(item.id)
                itens.remove(item)
            }
        }
        calculateTotal()
    }

    /**
     * Calcula o valor total do pedido com base nos itens e suas quantidades.
     */
    private fun calculateTotal() {
        var newTotal = 0.0
        for (item in itens) {
            val quantity = quantidades[item.id] ?: 0
            newTotal += item.preco * quantity
        }
        total = newTotal  // Agora estamos atualizando o campo total corretamente
    }

    /**
     * Retorna a data formatada do pedido com base no timestamp.
     */
    fun getFormattedDate(): String {
        val date = Date(timestamp)
        val format = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return format.format(date)
    }

    /**
     * Converte o pedido para um mapa que pode ser salvo no Firestore.
     */
    fun toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "userId" to userId,  // Incluindo o userId
            "itens" to itens.map { it.toMap() },
            "quantidades" to quantidades,
            "total" to total,
            "timestamp" to timestamp
        )
    }

    /**
     * Cria um pedido a partir de um documento do Firestore.
     * @param document DocumentSnapshot fornecido pelo Firestore.
     * @return Instância de Order.
     */
    companion object {
        fun fromDocument(document: DocumentSnapshot): OrderItem {
            val itensList = (document.get("itens") as? List<Map<String, Any>>)?.map { map ->
                MenuItem(
                    id = map["id"] as? String ?: "",
                    nome = map["nome"] as? String ?: "",
                    descricao = map["descricao"] as? String ?: "",
                    preco = map["preco"] as? Double ?: 0.0,
                    imagemUrl = map["imagemUrl"] as? String ?: "",
                    categoria = map["categoria"] as? String ?: ""
                )
            } ?: emptyList()

            return OrderItem(
                id = document.id,
                userId = document.getString("userId") ?: "", // Garantir que o userId seja recuperado
                itens = itensList.toMutableList(),
                quantidades = document.get("quantidades") as? MutableMap<String, Int> ?: mutableMapOf(),
                total = document.getDouble("total") ?: 0.0,
                timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()
            )
        }
    }
}

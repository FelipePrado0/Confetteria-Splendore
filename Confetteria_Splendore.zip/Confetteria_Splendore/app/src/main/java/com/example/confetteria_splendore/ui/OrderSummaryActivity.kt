package com.example.confetteria_splendore.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.confetteria_splendore.databinding.ActivityOrderSummaryBinding
import com.example.confetteria_splendore.model.OrderItem
import com.example.confetteria_splendore.viewmodel.OrderViewModel

class OrderSummaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOrderSummaryBinding
    private val orderViewModel: OrderViewModel by viewModels()

    private lateinit var orderSummaryAdapter: OrderSummaryAdapter
    private var currentOrder: OrderItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configurar binding
        binding = ActivityOrderSummaryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurar RecyclerView
        orderSummaryAdapter = OrderSummaryAdapter()
        binding.recyclerViewOrderSummary.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewOrderSummary.adapter = orderSummaryAdapter

        // Observando o estado do pedido
        orderViewModel.orderItem.observe(this) { orderItem ->
            currentOrder = orderItem
            if (orderItem.itens.isEmpty()) {
                showToast("O pedido está vazio!")
            } else {
                orderSummaryAdapter.submitList(orderItem.itens)
                updateTotal(orderItem)  // Corrigido aqui
            }
        }

        // Confirmar pedido
        binding.btnConfirm.setOnClickListener {
            currentOrder?.let { order ->
                orderViewModel.confirmOrder()  // Remover argumentos extras
                showToast("Pedido confirmado com sucesso!")  // Usando showToast diretamente
                finish()  // Fecha a tela após confirmação
            }
        }
    }

    // Atualiza o total do pedido
    private fun updateTotal(orderItem: OrderItem) {
        val total = orderItem.total
        binding.textTotal.text = "Total: R$ %.2f".format(total)
    }

    // Exibir mensagens curtas
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

package com.example.confetteria_splendore.utils

object Constants {

    // Firebase Collections
    const val COLLECTION_USERS = "users"
    const val COLLECTION_MENU = "menu"
    const val COLLECTION_ORDERS = "orders"

    // Firebase Fields
    const val FIELD_NAME = "name"
    const val FIELD_EMAIL = "email"
    const val FIELD_CREATED_AT = "created_at"
    const val FIELD_PRICE = "price"
    const val FIELD_DESCRIPTION = "description"
    const val FIELD_CATEGORY = "category"
    const val FIELD_IMAGE_URL = "image_url"

    // User Data Keys (used in SharedPreferences, for example)
    const val PREFS_USER_ID = "user_id"
    const val PREFS_USER_NAME = "user_name"
    const val PREFS_USER_EMAIL = "user_email"

    // Firebase Authentication error messages
    const val ERROR_INVALID_EMAIL = "Email inválido."
    const val ERROR_EMAIL_ALREADY_IN_USE = "O email já está em uso."
    const val ERROR_WEAK_PASSWORD = "A senha deve ter pelo menos 6 caracteres."

    // Other Constants
    const val DEFAULT_PASSWORD = "123456"
}

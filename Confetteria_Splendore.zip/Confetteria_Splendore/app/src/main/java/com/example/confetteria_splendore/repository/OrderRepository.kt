package com.example.confetteria_splendore.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.example.confetteria_splendore.model.OrderItem
import kotlinx.coroutines.tasks.await

class OrderRepository {

    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    /**
     * Recupera todos os pedidos do Firestore.
     * @return List<OrderItem> Uma lista com todos os pedidos.
     */
    suspend fun getOrders(): List<OrderItem> {
        return try {
            val snapshot = firestore.collection("orders").get().await()
            snapshot.documents.mapNotNull { it.toObject(OrderItem::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Recupera um pedido pelo ID do pedido.
     * @param orderId O ID do pedido.
     * @return OrderItem? O pedido encontrado ou null se não encontrado.
     */
    suspend fun getOrderById(orderId: String): OrderItem? {
        return try {
            val document = firestore.collection("orders").document(orderId).get().await()
            document.toObject(OrderItem::class.java)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Adiciona um novo pedido ao Firestore.
     * @param orderItem O pedido a ser adicionado.
     * @return Boolean indicando se a operação foi bem-sucedida.
     */
    suspend fun addOrder(orderItem: OrderItem): Boolean {
        return try {
            val newOrderRef = firestore.collection("orders").document() // Cria um novo documento com um ID gerado automaticamente
            val orderWithId = orderItem.copy(id = newOrderRef.id)  // Cria um novo OrderItem com o ID gerado
            newOrderRef.set(orderWithId.toMap()).await()
            true
        } catch (e: Exception) {
            false
        }
    }


    /**
     * Atualiza os dados de um pedido no Firestore.
     * @param orderId O ID do pedido a ser atualizado.
     * @param orderItem O novo pedido com dados atualizados.
     * @return Boolean indicando se a operação foi bem-sucedida.
     */
    suspend fun updateOrder(orderId: String, orderItem: OrderItem): Boolean {
        return try {
            firestore.collection("orders").document(orderId).set(orderItem.toMap()).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Exclui um pedido do Firestore.
     * @param orderId O ID do pedido a ser excluído.
     * @return Boolean indicando se a operação foi bem-sucedida.
     */
    suspend fun deleteOrder(orderId: String): Boolean {
        return try {
            firestore.collection("orders").document(orderId).delete().await()
            true
        } catch (e: Exception) {
            false
        }
    }
}

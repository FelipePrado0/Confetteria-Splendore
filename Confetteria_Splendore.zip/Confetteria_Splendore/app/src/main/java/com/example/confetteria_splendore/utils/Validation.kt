package com.example.confetteria_splendore.utils

import android.util.Patterns

object Validation {

    // Valida um email no formato correto
    fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    // Valida se a senha tem pelo menos 6 caracteres
    fun isValidPassword(password: String): Boolean {
        return password.length >= 6
    }

    // Valida se o nome não está vazio
    fun isValidName(name: String): Boolean {
        return name.isNotEmpty()
    }

    // Valida se a string não está vazia (usado para vários campos)
    fun isNotEmpty(value: String): Boolean {
        return value.isNotBlank()
    }
}

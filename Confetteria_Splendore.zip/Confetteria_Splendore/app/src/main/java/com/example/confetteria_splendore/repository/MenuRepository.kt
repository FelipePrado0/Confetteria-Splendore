package com.example.confetteria_splendore.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.example.confetteria_splendore.model.MenuItem
import kotlinx.coroutines.tasks.await

class MenuRepository {

    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    /**
     * Recupera todos os itens do cardápio do Firestore.
     * @return List<MenuItem> uma lista com os itens do cardápio.
     */
    suspend fun getMenuItems(): List<MenuItem> {
        return try {
            val snapshot = firestore.collection("menu").get().await()
            val menuItems = mutableListOf<MenuItem>()
            for (document in snapshot.documents) {
                val menuItem = document.toObject(MenuItem::class.java)
                menuItem?.let {
                    menuItems.add(it)
                }
            }
            menuItems
        } catch (e: Exception) {
            emptyList() // Retorna uma lista vazia em caso de erro
        }
    }

    /**
     * Recupera itens do cardápio filtrados por categoria.
     * @param category A categoria dos itens do cardápio.
     * @return List<MenuItem> lista de itens filtrados pela categoria.
     */
    suspend fun getMenuItemsByCategory(category: String): List<MenuItem> {
        return try {
            val snapshot = firestore.collection("menu")
                .whereEqualTo("category", category)
                .get()
                .await()
            val menuItems = mutableListOf<MenuItem>()
            for (document in snapshot.documents) {
                val menuItem = document.toObject(MenuItem::class.java)
                menuItem?.let {
                    menuItems.add(it)
                }
            }
            menuItems
        } catch (e: Exception) {
            emptyList() // Retorna uma lista vazia em caso de erro
        }
    }

    /**
     * Recupera um item do cardápio pelo seu ID.
     * @param itemId O ID do item.
     * @return MenuItem? O item do cardápio ou null se não encontrado.
     */
    suspend fun getMenuItemById(itemId: String): MenuItem? {
        return try {
            val document = firestore.collection("menu").document(itemId).get().await()
            document.toObject(MenuItem::class.java)
        } catch (e: Exception) {
            null // Retorna null em caso de erro
        }
    }

    /**
     * Adiciona um novo item ao cardápio no Firestore.
     * @param menuItem O item do cardápio a ser adicionado.
     */
    fun addMenuItem(name: String, descricao: String, valor: Double, imageUrl: String?) {
        val item = hashMapOf(
            "name" to name,
            "description" to descricao,
            "price" to valor,
            "image_url" to imageUrl
        )

        db.collection("menu")
            .add(item)
            .addOnSuccessListener { documentReference ->
                Log.d("Firestore", "Item adicionado com ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Erro ao adicionar item", e)
            }
    }


    /**
     * Atualiza os dados de um item do cardápio.
     * @param itemId O ID do item que será atualizado.
     * @param menuItem O novo item com dados atualizados.
     * @return Boolean indicando o sucesso ou falha da operação.
     */
    suspend fun updateMenuItem(itemId: String, menuItem: MenuItem): Boolean {
        return try {
            firestore.collection("menu").document(itemId).set(menuItem.toMap()).await()
            true // Retorna true se a atualização for bem-sucedida
        } catch (e: Exception) {
            false // Retorna false em caso de erro
        }
    }

    /**
     * Exclui um item do cardápio do Firestore.
     * @param itemId O ID do item que será excluído.
     * @return Boolean indicando o sucesso ou falha da operação.
     */
    suspend fun deleteMenuItem(itemId: String): Boolean {
        return try {
            firestore.collection("menu").document(itemId).delete().await()
            true // Retorna true se a exclusão for bem-sucedida
        } catch (e: Exception) {
            false // Retorna false em caso de erro
        }
    }
}

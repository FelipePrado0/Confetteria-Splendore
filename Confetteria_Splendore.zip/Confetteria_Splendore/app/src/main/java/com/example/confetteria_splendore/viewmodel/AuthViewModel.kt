package com.example.confetteria_splendore.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.confetteria_splendore.repository.AuthRepository
import com.example.confetteria_splendore.utils.Validation
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch
import com.example.confetteria_splendore.model.User


class AuthViewModel : ViewModel() {

    private val authRepository = AuthRepository()

    // LiveData para os estados do processo de login e registro
    private val _authState = MutableLiveData<AuthState>()
    val authState: LiveData<AuthState> get() = _authState

    // Função para fazer o login
    fun login(email: String, password: String) {
        if (validateLoginData(email, password)) {
            _authState.value = AuthState.Loading
            viewModelScope.launch {
                try {
                    val user = authRepository.login(email, password)
                    if (user != null) {
                        _authState.value = AuthState.Success(user)
                    } else {
                        _authState.value = AuthState.Error("Login falhou")
                    }
                } catch (e: Exception) {
                    _authState.value = AuthState.Error(e.message ?: "Erro desconhecido")
                }
            }
        } else {
            _authState.value = AuthState.Error("Dados de login inválidos")
        }
    }

    // Função para fazer o registro de novo usuário
    fun register(name: String, email: String, password: String) {
        if (validateRegisterData(name, email, password)) {
            _authState.value = AuthState.Loading
            viewModelScope.launch {
                try {
                    val user = authRepository.register(email, password, User(nome = name, email = email))
                    if (user != null) {
                        _authState.value = AuthState.Success(user)
                    } else {
                        _authState.value = AuthState.Error("Erro ao registrar o usuário")
                    }
                } catch (e: Exception) {
                    _authState.value = AuthState.Error(e.message ?: "Erro desconhecido")
                }
            }
        } else {
            _authState.value = AuthState.Error("Dados de registro inválidos")
        }
    }

    // Função para validar os dados de login
    private fun validateLoginData(email: String, password: String): Boolean {
        return Validation.isValidEmail(email) && Validation.isValidPassword(password)
    }

    // Função para validar os dados de registro
    private fun validateRegisterData(name: String, email: String, password: String): Boolean {
        return Validation.isValidName(name) && Validation.isValidEmail(email) && Validation.isValidPassword(password)
    }

    // Função para fazer o logout
    fun logout() {
        authRepository.logout()
        _authState.value = AuthState.LoggedOut
    }

    // Função para verificar se o usuário está logado
    fun checkCurrentUser() {
        val currentUser = authRepository.getCurrentUser()
        if (currentUser != null) {
            _authState.value = AuthState.Success(currentUser)
        } else {
            _authState.value = AuthState.LoggedOut
        }
    }

    // Enum para representar os diferentes estados da autenticação
    sealed class AuthState {
        object Loading : AuthState()
        object LoggedOut : AuthState()
        data class Success(val user: FirebaseUser) : AuthState()
        data class Error(val message: String) : AuthState()
    }
}

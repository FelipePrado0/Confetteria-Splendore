package com.example.confetteria_splendore

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.confetteria_splendore.databinding.ActivityMainBinding
import com.example.confetteria_splendore.viewmodel.MenuViewModel
import com.example.confetteria_splendore.viewmodel.OrderViewModel
import com.example.confetteria_splendore.ui.MenuFragment
import com.example.confetteria_splendore.ui.OrderSummaryActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val menuViewModel: MenuViewModel by viewModels()
    private val orderViewModel: OrderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = FirebaseFirestore.getInstance()

        // Observando os itens do cardápio
        menuViewModel.menuItems.observe(this, Observer { menuItems ->
            if (menuItems != null && menuItems.isNotEmpty()) {
                println("Itens do menu carregados: $menuItems")
            } else {
                println("Nenhum item encontrado no menu")
            }
        })

        // Observando o estado do pedido
        orderViewModel.orderItem.observe(this, Observer { orderItem ->
            orderItem?.let {
                println("Pedido carregado: $it")
            } ?: run {
                println("Pedido ainda não iniciado")
            }
        })

        // Botões e ações
        binding.btnOrder.setOnClickListener {
            val itemId = "item_1"
            val quantity = 1
            val price = 15.0
            orderViewModel.addItemToOrder(itemId, quantity, price)
        }

        binding.btnMenu.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, MenuFragment())
                .commit()
        }

        binding.btnOrderSummary.setOnClickListener {
            orderViewModel.orderItem.value?.let {
                val intent = Intent(this, OrderSummaryActivity::class.java)
                intent.putExtra("ORDER_ID", it.id)
                startActivity(intent)
            } ?: showToast("Pedido ainda não iniciado")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

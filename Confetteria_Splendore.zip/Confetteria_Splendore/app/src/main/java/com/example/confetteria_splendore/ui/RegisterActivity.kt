package com.example.confetteria_splendore.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.confetteria_splendore.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseUser

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializando o Firebase Authentication e Firestore
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Ação para o botão de registro
        binding.buttonRegister.setOnClickListener {
            val name = binding.editTextName.text.toString()
            val email = binding.editTextEmail.text.toString()
            val password = binding.editTextPassword.text.toString()
            val confirmPassword = binding.editTextConfirmPassword.text.toString()

            if (isValidInput(name, email, password, confirmPassword)) {
                registerUser(name, email, password)
            }
        }
    }

    // Função para validar os dados de entrada
    private fun isValidInput(name: String, email: String, password: String, confirmPassword: String): Boolean {
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showToast("Todos os campos são obrigatórios")
            return false
        }
        if (password != confirmPassword) {
            showToast("As senhas não coincidem")
            return false
        }
        return true
    }

    // Função para registrar o usuário no Firebase Authentication
    private fun registerUser(name: String, email: String, password: String) {
        // Exibe o indicador de progresso
        binding.progressBar.visibility = View.VISIBLE

        // Inicia o registro do usuário no Firebase Authentication
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                // Sempre esconde o progresso após a conclusão da tarefa
                binding.progressBar.visibility = View.GONE

                if (task.isSuccessful) {
                    // Registro bem-sucedido, salva os dados no Firestore
                    val user = auth.currentUser
                    saveUserData(user, name)
                } else {
                    // Registro falhou, exibe mensagem de erro detalhada
                    val errorMessage = task.exception?.message ?: "Erro desconhecido"
                    showToast("Falha ao registrar: $errorMessage")
                }
            }
            .addOnFailureListener { exception ->
                // Manuseia qualquer exceção adicional
                binding.progressBar.visibility = View.GONE
                val errorMessage = exception.message ?: "Erro inesperado"
                showToast("Erro ao registrar usuário: $errorMessage")
            }
    }

    // Função para salvar os dados do usuário no Firestore
    // Função para salvar os dados do usuário no Firestore
    private fun saveUserData(user: FirebaseUser?, name: String) {
        if (user != null) {
            val userData = hashMapOf(
                "name" to name,
                "email" to user.email,
                "created_at" to com.google.firebase.Timestamp.now()
            )

            firestore.collection("users").document(user.uid)
                .set(userData)
                .addOnSuccessListener {
                    showToast("Cadastro realizado com sucesso!")

                    // Redireciona o usuário para a tela de login
                    val intent = Intent(this, LoginActivity::class.java)

                    // As flags abaixo garantem que a tela de login seja a única na pilha de atividades
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                }
                .addOnFailureListener {
                    showToast("Erro ao salvar dados do usuário.")
                }
        }
    }


    // Função para mostrar mensagens toast
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

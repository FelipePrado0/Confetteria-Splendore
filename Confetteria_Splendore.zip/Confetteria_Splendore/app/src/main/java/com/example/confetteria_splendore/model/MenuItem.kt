package com.example.confetteria_splendore.model

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.QueryDocumentSnapshot

/**
 * Representa um item do cardápio.
 */
data class MenuItem(
    val id: String = "",
    val nome: String = "",
    val descricao: String = "",
    val preco: Double = 0.0,
    val imagemUrl: String = "",
    val categoria: String = ""
) {

    /**
     * Converte o objeto MenuItem para um mapa que pode ser salvo no Firestore.
     */
    fun toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "nome" to nome,
            "descricao" to descricao,
            "preco" to preco,
            "imagemUrl" to imagemUrl,
            "categoria" to categoria
        )
    }

    companion object {
        fun fromDocument(document: DocumentSnapshot): MenuItem {
            return MenuItem(
                id = document.id,
                nome = document.getString("nome") ?: "",
                descricao = document.getString("descricao") ?: "",
                preco = document.getDouble("preco") ?: 0.0,
                imagemUrl = document.getString("imagemUrl") ?: "",
                categoria = document.getString("categoria") ?: ""
            )
        }

        fun fromQueryDocument(document: QueryDocumentSnapshot): MenuItem {
            return fromDocument(document)
        }
    }

    fun getFormattedPrice(): String {
        return "R$ %.2f".format(preco)
    }

    fun isValid(): Boolean {
        return nome.isNotBlank() && preco > 0 && imagemUrl.isNotBlank()
    }
}

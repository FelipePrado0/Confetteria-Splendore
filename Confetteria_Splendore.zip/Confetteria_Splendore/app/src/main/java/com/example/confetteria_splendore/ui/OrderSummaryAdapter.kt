package com.example.confetteria_splendore.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import com.example.confetteria_splendore.databinding.ItemOrderSummaryBinding
import com.example.confetteria_splendore.model.MenuItem

class OrderSummaryAdapter : ListAdapter<MenuItem, OrderSummaryAdapter.OrderViewHolder>(ItemDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemOrderSummaryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class OrderViewHolder(private val binding: ItemOrderSummaryBinding) : androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {
        fun bind(item: MenuItem) {
            binding.textItemName.text = item.nome
            binding.textItemPrice.text = "R$ %.2f".format(item.preco)
            // Definir as ações para aumentar ou diminuir a quantidade
            binding.btnIncrease.setOnClickListener { /* aumentar quantidade */ }
            binding.btnDecrease.setOnClickListener { /* diminuir quantidade */ }
        }
    }

    class ItemDiffCallback : DiffUtil.ItemCallback<MenuItem>() {
        override fun areItemsTheSame(oldItem: MenuItem, newItem: MenuItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: MenuItem, newItem: MenuItem): Boolean {
            return oldItem == newItem
        }
    }
}

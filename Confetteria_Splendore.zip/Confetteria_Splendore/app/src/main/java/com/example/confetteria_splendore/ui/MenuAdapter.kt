package com.example.confetteria_splendore.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.confetteria_splendore.databinding.ItemMenuBinding
import com.example.confetteria_splendore.model.MenuItem

// Adapte esta classe para o seu projeto (verifique o tipo de item e a comparação)
class MenuAdapter : ListAdapter<MenuItem, MenuAdapter.MenuViewHolder>(MenuItemDiffCallback()) {

    // ViewHolder que irá gerenciar a exibição de cada item
    class MenuViewHolder(private val binding: ItemMenuBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(menuItem: MenuItem) {
            // Vincula os dados do menuItem aos elementos do layout
            binding.tvItemName.text = menuItem.nome  // Usando 'nome' no lugar de 'name'
            binding.tvItemPrice.text = menuItem.getFormattedPrice()  // Usando 'preco' com o método 'getFormattedPrice()'
        }
    }

    // Inflar o layout de cada item e criar o ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
        val binding = ItemMenuBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MenuViewHolder(binding)
    }

    // Vincula os dados ao ViewHolder
    override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
        val menuItem = getItem(position)
        holder.bind(menuItem)
    }
}

// Classe de comparação para o ListAdapter, usada para otimizar a atualização dos itens
class MenuItemDiffCallback : androidx.recyclerview.widget.DiffUtil.ItemCallback<MenuItem>() {
    override fun areItemsTheSame(oldItem: MenuItem, newItem: MenuItem): Boolean {
        // Aqui você pode comparar o ID do item (ou outro atributo único)
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: MenuItem, newItem: MenuItem): Boolean {
        // Compara os conteúdos do item (nome e preço)
        return oldItem == newItem
    }
}

package com.example.confetteria_splendore.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.confetteria_splendore.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.example.confetteria_splendore.MainActivity
import com.example.confetteria_splendore.ui.RegisterActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializa o FirebaseAuth
        auth = FirebaseAuth.getInstance()

        // Listener para o botão de login
        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                loginUser(email, password)
            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        // Listener para o botão de cadastro
        binding.btnSignup.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    /**
     * Função para realizar o login do usuário com Firebase Authentication.
     * @param email O email do usuário.
     * @param password A senha do usuário.
     */
    private fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Login bem-sucedido, redirecionar para a tela principal
                    val user = auth.currentUser
                    Toast.makeText(this, "Login bem-sucedido", Toast.LENGTH_SHORT).show()

                    // Iniciar a tela principal do aplicativo
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish() // Finaliza a LoginActivity para que o usuário não possa voltar
                } else {
                    // Falha no login, exibir uma mensagem de erro
                    Toast.makeText(this, "Falha no login: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }
}

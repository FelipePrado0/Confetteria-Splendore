package com.example.confetteria_splendore.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.confetteria_splendore.model.MenuItem
import com.example.confetteria_splendore.model.OrderItem
import com.example.confetteria_splendore.repository.OrderRepository
import kotlinx.coroutines.launch

class OrderViewModel : ViewModel() {

    private val orderRepository = OrderRepository()

    // LiveData para armazenar o pedido
    private val _orderItem = MutableLiveData<OrderItem>()
    val orderItem: LiveData<OrderItem> get() = _orderItem

    // Função para iniciar um pedido
    fun startOrder(userId: String) {
        val newOrderItem = OrderItem(userId = userId)  // Corrigido para passar o userId
        _orderItem.value = newOrderItem
    }

    // Função para adicionar um item ao pedido
    fun addItemToOrder(itemId: String, quantity: Int, price: Double) {
        _orderItem.value?.let { currentOrder ->
            val menuItem = MenuItem(itemId, "", "", price, "", "")  // Criando um MenuItem fictício
            currentOrder.addItem(menuItem)  // Adiciona o item ao pedido
            _orderItem.value = currentOrder
        }
    }

    // Função para remover um item do pedido
    fun removeItemFromOrder(itemId: String) {
        _orderItem.value?.let { currentOrder ->
            val menuItem = currentOrder.itens.find { it.id == itemId }  // Encontra o item
            menuItem?.let {
                currentOrder.removeItem(it)  // Remove o item
                _orderItem.value = currentOrder
            }
        }
    }

    // Função para confirmar o pedido, agora usando viewModelScope para chamar a função suspensa addOrder
    fun confirmOrder() {
        _orderItem.value?.let { order ->
            // Lançando uma coroutine para chamar a função suspensa
            viewModelScope.launch {
                val result = orderRepository.addOrder(order)  // Chama addOrder dentro de uma coroutine
                if (result) {
                    // Pedido adicionado com sucesso
                } else {
                    // Falha ao adicionar o pedido
                }
            }
        }
    }
}

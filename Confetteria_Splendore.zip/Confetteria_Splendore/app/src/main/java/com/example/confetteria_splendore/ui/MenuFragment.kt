package com.example.confetteria_splendore.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.confetteria_splendore.databinding.ActivityMenuBinding // Alterado para ActivityMenuBinding
import com.example.confetteria_splendore.model.MenuItem
import com.example.confetteria_splendore.repository.MenuRepository
import com.google.firebase.firestore.FirebaseFirestore
import androidx.recyclerview.widget.RecyclerView

class MenuFragment : Fragment() {

    private lateinit var binding: ActivityMenuBinding // Alterado para ActivityMenuBinding
    private lateinit var menuAdapter: MenuAdapter
    private val firestore = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflando o layout do fragmento
        binding = ActivityMenuBinding.inflate(inflater, container, false)

        // Inicializando o RecyclerView
        menuAdapter = MenuAdapter()
        binding.recyclerViewMenuItems.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewMenuItems.adapter = menuAdapter

        // Carregar os itens do cardápio
        loadMenuItems()

        return binding.root
    }

    private fun loadMenuItems() {
        // Obter dados do Firestore
        firestore.collection("menu")
            .get()
            .addOnSuccessListener { result ->
                val menuItems = mutableListOf<MenuItem>()
                for (document in result) {
                    val item = document.toObject(MenuItem::class.java)
                    menuItems.add(item)
                }
                // Atualiza o adapter com os dados do Firestore
                menuAdapter.submitList(menuItems)
            }
            .addOnFailureListener { exception ->
                // Tratar falhas ao carregar dados
                exception.printStackTrace()
            }
    }
}

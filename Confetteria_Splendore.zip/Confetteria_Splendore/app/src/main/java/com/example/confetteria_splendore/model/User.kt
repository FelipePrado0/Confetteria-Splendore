package com.example.confetteria_splendore.model

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

/**
 * Representa um usuário do aplicativo.
 */
data class User(
    val id: String = "",
    val nome: String = "",
    val email: String = "",
    @ServerTimestamp val createdAt: Date? = null
) {

    /**
     * Verifica se o usuário possui os dados básicos válidos.
     */
    fun isValid(): Boolean {
        return nome.isNotBlank() && email.isNotBlank() && email.contains("@")
    }

    /**
     * Converte o objeto User para um mapa que pode ser salvo no Firestore.
     */
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "nome" to nome,
            "email" to email,
            "createdAt" to (createdAt ?: Date()) // Se `createdAt` for nulo, insere a data atual
        )
    }

    /**
     * Cria um objeto User a partir de um documento do Firestore.
     * @param document DocumentSnapshot fornecido pelo Firestore.
     * @return Instância de User.
     */
    companion object {
        fun fromDocument(document: DocumentSnapshot): User {
            return User(
                id = document.id,
                nome = document.getString("nome") ?: "",
                email = document.getString("email") ?: "",
                createdAt = document.getTimestamp("createdAt")?.toDate()
            )
        }
    }

    /**
     * Exclui o ID do objeto ao serializar para Firestore.
     */
    @Exclude
    fun excludeId(): Map<String, Any?> {
        return mapOf(
            "nome" to nome,
            "email" to email,
            "createdAt" to (createdAt ?: Date()) // Insere a data atual se estiver nula
        )
    }
}
